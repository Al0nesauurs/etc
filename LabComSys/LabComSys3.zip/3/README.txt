How to run sel_sort.s
$ spim -f sel_sort.s < TEST.dat

How to check Execution time
$ time(spim -f sel_sort.s < TEST.dat)

Overall effective CPI. = (Execution time*Frequency)/Instruction Count